#Importamos las librerias de socket
import socket
import threading
import gameboard as gb

from tkinter import *
from tkinter import messagebox
from tkinter import simpledialog

#Definir la informacion de mi socket
serverAddress = None
serverPort = None

#crear un objeto en mi servidor
connectionSocket = None

start = False
user = False
player1 = ""
board = None
pos = 0
finish = False
username = ""
isCon = False
close = False

def createThread(con):
    thread = threading.Thread(target=con)
    thread.daemon = True
    thread.start()

#Recibir el movimiento del player1
def receiveMove():
    global pos,start,user
    while True:  
        if isCon and start and user:
            try:
                data,addr = connectionSocket.recvfrom(1024)
                data = data.decode()
                print(data)    
                if data != "":     
                    pos,board.lastMove = data.split("-")
                    board.playMoveOnBoard(int(pos),board.lastMove)
                    updateBoard()
                    lblTurn["text"] = "tu"
                    play()
            except:
                lblTurn["text"] = "tu"
                pass
        

def receive():
    global start,user,board,username,player1,connectionSocket,isCon,close
    while True:
        if isCon:
            if (not start or not user):
                data,addr = connectionSocket.recvfrom(1024)
                data = data.decode()
                print(data)
                if data == "No aceptado":
                    isCon = True
                    connectionSocket.close()
                elif data == "aceptado":
                    username = simpledialog.askstring("Input", "Ingresa tu nombre?",parent=window)
                    #username = "maneesha"
                    sendData = '{}'.format(username).encode()
                    connectionSocket.send(sendData)
                    lblUsername["text"] = username
                    print(sendData)
                    start = True   
                    close = False            
                elif data == "player1": 
                    player1 = data              
                    board = gb.Board(username)
                    board.lastMove = player1
                    user = True
                    break

#preguntando datos para conectarce con player 1
def clickConnect():
    global serverAddress,serverPort,connectionSocket,isCon
    if not isCon:
        serverAddress = simpledialog.askstring("Input", "cual es el host/Direccion IP?",parent=window)
        serverPort = simpledialog.askstring("Input", "Cual es el puerto?",parent=window)
        if serverAddress != "" and serverPort != "":
            try:
                connectionSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                connectionSocket.connect((serverAddress,int(serverPort)))
                isCon = True
                lblTurn["text"] = "tu"
                lblGames["text"] = " "
                lblWon["text"] = " "
                lblLost["text"] = " "
                lblTies["text"] = " "
                lblUsername["text"] = " "
                try:
                    receive()
                except Exception:
                    isCon = False
                    messagebox.showerror("Error", "Host rechazo la conexion!")
            except Exception:
                messagebox.showerror("Error", "No se reconoce este puerto o host!")
        else:
            messagebox.showerror("Error", "Puerto o host invalido!")
 

def clickQuit():
    if start or user:
        connectionSocket.close()
    window.destroy()


createThread(receiveMove)


window=Tk()
window.title("Player2")
window.geometry("850x650+100+100")
window.resizable(width=False, height=False)
window.configure(background = 'MediumAquamarine')

tops = Frame(window, bg ='MediumAquamarine', pady =2, width = 1350, height=100, relief = RIDGE)
tops.grid(row=0, column =0)

lblTitle = Label(tops, font=('arial',50,'bold'),text="Juego Tic Tac Toe", bd=21, bg='MediumAquamarine',fg='Cornsilk',justify = CENTER)
lblTitle.grid(row=0,column = 0)

mainFrame = Frame (window, bg = 'Powder Blue', bd=10,width = 1350, height=600, relief=RIDGE) 
mainFrame.grid(row=1,column=0)

leftFrame = Frame (mainFrame ,bd=10, width =750, height=500, pady=2, padx=10, bg="MediumAquamarine", relief=RIDGE)
leftFrame.pack(side=LEFT)

rightFrame = Frame (mainFrame,bd=10, width =560, height=500, padx=10, pady=2, bg="MediumAquamarine", relief=RIDGE)
rightFrame.pack(side=RIGHT)

rightFrame1=Frame(rightFrame ,bd=10, width=560, height=200, padx=10, pady=2, bg="MediumAquamarine", relief=RIDGE) 
rightFrame1.grid(row=0, column=0)

rightFrame2 = Frame(rightFrame,bd=10, width =560, height=250, padx=10, pady=2, bg="MediumAquamarine", relief=RIDGE)
rightFrame2.grid(row=1,column=0)

rightFrame3=Frame(rightFrame ,bd=10, width=560, height=150, padx=10, pady=2, bg="MediumAquamarine", relief=RIDGE) 
rightFrame3.grid(row=2, column=0)



def clicked1():
    global finish,board
    if start and user and btn1["text"]==" ":   #Para obtener el texto de los botones del cuadro que el jugador elija
        if board.lastMove == player1:
            btn1["text"]="X"
            board.lastMove = username
            sendData = '{}-{}'.format("0",board.lastMove).encode()
            connectionSocket.send(sendData)
            board.playMoveOnBoard(0,board.lastMove)
            lblTurn["text"] = "Oponente" #muestra de quien es el turno
            print(sendData)   
            play()
        
def clicked2():
    global finish,board
    if start and user and btn2["text"]==" ":   #Para obtener el texto de los botones del cuadro que el jugador elija
        if board.lastMove == player1:
            btn2["text"]="X"
            board.lastMove = username
            sendData = '{}-{}'.format("1",board.lastMove).encode()
            connectionSocket.send(sendData)
            board.playMoveOnBoard(1,board.lastMove)
            lblTurn["text"] = "Oponente" #muestra de quien es el turno
            print(sendData)    
            play()

def clicked3():
    global finish,board
    if start and user and btn3["text"]==" ":   #Para obtener el texto de los botones del cuadro que el jugador elija
        if board.lastMove == player1:
            btn3["text"]="X"
            board.lastMove = username
            sendData = '{}-{}'.format("2",board.lastMove).encode()
            connectionSocket.send(sendData)
            board.playMoveOnBoard(2,board.lastMove)
            lblTurn["text"] = "Oponente"  #muestra de quien es el turno
            print(sendData)    
            play()

def clicked4():
    global finish,board
    if start and user and btn4["text"]==" ":   #Para obtener el texto de los botones del cuadro que el jugador elija
        if board.lastMove == player1:
            btn4["text"]="X"
            board.lastMove = username
            sendData = '{}-{}'.format("3",board.lastMove).encode()
            connectionSocket.send(sendData)
            board.playMoveOnBoard(3,board.lastMove)
            lblTurn["text"] = "Oponente" #muestra de quien es el turno
            print(sendData)    
            play()

def clicked5():
    global finish,board
    if start and user and btn5["text"]==" ":   #Para obtener el texto de los botones del cuadro que el jugador elija
        if board.lastMove == player1:
            btn5["text"]="X"
            board.lastMove = username
            sendData = '{}-{}'.format("4",board.lastMove).encode()
            connectionSocket.send(sendData)
            board.playMoveOnBoard(4,board.lastMove)
            lblTurn["text"] = "Oponente" #muestra de quien es el turno
            print(sendData)     
            play()

def clicked6():
    global finish,board
    if start and user and btn6["text"]==" ":   #Para obtener el texto de los botones del cuadro que el jugador elija
        if board.lastMove == player1:
            btn6["text"]="X"
            board.lastMove = username
            sendData = '{}-{}'.format("5",board.lastMove).encode()
            connectionSocket.send(sendData)
            board.playMoveOnBoard(5,board.lastMove)
            lblTurn["text"] = "Oponente" #muestra de quien es el turno
            print(sendData)   
            play()

def clicked7():
    global finish,board
    if start and user and btn7["text"]==" ":   #Para obtener el texto de los botones del cuadro que el jugador elija
        if board.lastMove == player1:
            btn7["text"]="X"
            board.lastMove = username
            sendData = '{}-{}'.format("6",board.lastMove).encode()
            connectionSocket.send(sendData)
            board.playMoveOnBoard(6,board.lastMove)
            lblTurn["text"] = "Oponente" #muestra de quien es el turno
            print(sendData)  
            play()

def clicked8():
    global finish,board
    if start and user and btn8["text"]==" ":   #Para obtener el texto de los botones del cuadro que el jugador elija
        if board.lastMove == player1:
            btn8["text"]="X"
            board.lastMove = username
            sendData = '{}-{}'.format("7",board.lastMove).encode()
            connectionSocket.send(sendData)
            board.playMoveOnBoard(7,board.lastMove)
            lblTurn["text"] = "Oponente" #muestra de quien es el turno
            print(sendData)    
            play()

def clicked9():
    global finish,board
    if start and user and btn9["text"]==" ":   #Para obtener el texto de los botones del cuadro que el jugador elija
        if board.lastMove == player1:
            btn9["text"]="X"
            board.lastMove = username
            sendData = '{}-{}'.format("8",board.lastMove).encode()
            connectionSocket.send(sendData)
            board.playMoveOnBoard(8,board.lastMove)
            lblTurn["text"] = "Oponente" #muestra de quien es el turno
            print(sendData)    
            play()

# Preguntar al jugador si quiere jugar de nuevo y en caso de ser si el juego continua, en caso de ser no el juego termina
#y muestra la puntuacion
def play():
    global isCon,start,user,close
    finish,won = board.isGameFinished()
    if finish:
        answer = messagebox.askyesno("Atencion","Quieres jugar de nuevo?")
        if answer:
            sendData = '{}'.format("Jugar de Nuevo").encode()
            connectionSocket.send(sendData)
            board.recordGamePlayed()
            reset()
        else:
            isCon = False
            sendData = '{}'.format("Divertidos").encode()
            connectionSocket.send(sendData)
            connectionSocket.close()
            start = False
            user = False
            close = True
            comData = board.computeStats()
            lblGames["text"] = comData["numGames"]
            lblWon["text"] = comData["wins"]["X"]
            lblLost["text"] = comData["loss"]["X"]
            lblTies["text"] = comData["ties"]
            lblTurn["text"] = "Tu"
            reset()
            
#limpiar las casillas
def reset():
    board.resetGameBoard()
    board.lastMove = player1
    btn1["text"]=" "
    btn2["text"]=" "
    btn3["text"]=" "
    btn4["text"]=" "
    btn5["text"]=" "
    btn6["text"]=" "
    btn7["text"]=" "
    btn8["text"]=" "
    btn9["text"]=" "
    
#respuesta player1
def updateBoard():
    if int(pos) == 0:
        btn1["text"]="O"
    elif int(pos) == 1:
        btn2["text"]="O"
    elif int(pos) == 2:
        btn3["text"]="O"
    elif int(pos) == 3:
        btn4["text"]="O"
    elif int(pos) == 4:
        btn5["text"]="O"
    elif int(pos) == 5:
        btn6["text"]="O"
    elif int(pos) == 6:
        btn7["text"]="O"
    elif int(pos) == 7:
        btn8["text"]="O"
    elif int(pos) == 8:
        btn9["text"]="O"

#casillas del juego
btn1 = Button(leftFrame, text=" ",bg="white", fg="Black",width=8,height=3,font=('Times', 20),command=clicked1)
btn1.grid(column=1, row=1, sticky = S+N+E+W)
btn2 = Button(leftFrame, text=" ",bg="white", fg="Black",width=8,height=3,font=('Times', 20), command=clicked2)
btn2.grid(column=2, row=1, sticky = S+N+E+W)
btn3 = Button(leftFrame, text=" ",bg="white", fg="Black",width=8,height=3,font=('Times', 20),command=clicked3)
btn3.grid(column=3, row=1, sticky = S+N+E+W)
btn4 = Button(leftFrame, text=" ",bg="white", fg="Black",width=8,height=3,font=('Times', 20),command=clicked4)
btn4.grid(column=1, row=2, sticky = S+N+E+W)
btn5 = Button(leftFrame, text=" ",bg="white", fg="Black",width=8,height=3,font=('Times', 20),command=clicked5)
btn5.grid(column=2, row=2, sticky = S+N+E+W)
btn6 = Button(leftFrame, text=" ",bg="white", fg="Black",width=8,height=3,font=('Times', 20),command=clicked6)
btn6.grid(column=3, row=2, sticky = S+N+E+W)
btn7 = Button(leftFrame, text=" ",bg="white", fg="Black",width=8,height=3,font=('Times', 20),command=clicked7)
btn7.grid(column=1, row=3, sticky = S+N+E+W)
btn8 = Button(leftFrame, text=" ",bg="white", fg="Black",width=8,height=3,font=('Times', 20),command=clicked8)
btn8.grid(column=2, row=3, sticky = S+N+E+W)
btn9 = Button(leftFrame, text=" ",bg="white", fg="Black",width=8,height=3,font=('Times', 20),command=clicked9)
btn9.grid(column=3, row=3, sticky = S+N+E+W)

#bton conectar y salir
btnConnect=Button(rightFrame3, text="Conectar", font=('arial', 17, 'bold'), height = 1, width =20,command=clickConnect)
btnConnect.grid (row=2, column=0 ,padx=6, pady=11)

btnQuit=Button (rightFrame3, text="Salir", font=('arial', 17, 'bold'), height = 1, width =20, command = clickQuit) 
btnQuit.grid(row=3, column=0 ,padx=6, pady=10)

#Resultados
lbl=Label(rightFrame2, font=('arial', 20, 'bold'), text="JUEGOS:",padx=2, pady=2, bg="MediumAquamarine") 
lbl.grid (row=0, column=0, sticky=W)
lblGames=Label(rightFrame2, font=('arial', 20, 'bold'), text=" ",padx=2, pady=2, bg="MediumAquamarine",width=10) 
lblGames.grid (row=0, column=1, sticky=W)
lbl=Label(rightFrame2, font=('arial', 20, 'bold'), text="Ganado:",padx=2, pady=2, bg="MediumAquamarine") 
lbl.grid (row=1, column=0, sticky=W)
lblWon=Label(rightFrame2, font=('arial', 20, 'bold'), text=" ",padx=2, pady=2, bg="MediumAquamarine",width=10) 
lblWon.grid (row=1, column=1, sticky=W)
lbl=Label(rightFrame2, font=('arial', 20, 'bold'), text="Perdido:",padx=2, pady=2, bg="MediumAquamarine") 
lbl.grid (row=2, column=0, sticky=W)
lblLost=Label(rightFrame2, font=('arial', 20, 'bold'), text=" ",padx=2, pady=2, bg="MediumAquamarine",width=10) 
lblLost.grid (row=2, column=1, sticky=W)
lbl=Label(rightFrame2, font=('arial', 20, 'bold'), text="Empate:",padx=2, pady=2, bg="MediumAquamarine") 
lbl.grid (row=3, column=0, sticky=W)
lblTies=Label(rightFrame2, font=('arial', 20, 'bold'), text=" ",padx=2, pady=2, bg="MediumAquamarine",width=10) 
lblTies.grid (row=3, column=1, sticky=W)

#Menu del player 

lbl=Label(rightFrame1, font=('arial', 20, 'bold'), text="Player2:",padx=2, pady=2, bg="MediumAquamarine") 
lbl.grid (row=0, column=0, sticky=W)
lblUsername=Label(rightFrame1, font=('arial', 20, 'bold'), text="",padx=2, pady=2, bg="MediumAquamarine",width=10) 
lblUsername.grid (row=0, column=1, sticky=W)
lbl=Label(rightFrame1, font=('arial', 20, 'bold'), text="Turno: ",padx=2, pady=2, bg="MediumAquamarine") 
lbl.grid (row=1, column=0, sticky=W)
lblTurn=Label(rightFrame1, font=('arial', 20, 'bold'), text="Tu",padx=2, pady=2, bg="MediumAquamarine",width=10) 
lblTurn.grid (row=1, column=1, sticky=W)


window.mainloop()