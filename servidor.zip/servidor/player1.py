#Importamos las librerias de socket
import socket
import threading
import gameboard as gb
import time

from tkinter import *
from tkinter import messagebox


# usando la dirección de bucle invertido como la dirección IP de mi servidor
serverAddress = '0.0.0.0'

# definir un número de puerto para mi servidor
port = 8000

# crear un objeto de socket en mi servidor
serverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# vincular mi host con mi número de puerto
serverSocket.bind((serverAddress,port))

# configurar mi socket usando la función de escucha
# 1 designa el número máximo de conexiones de mi socket
serverSocket.listen(1)

clientSocket,clientAddress = None,None

start = False
user = False
player2 = ""
board = None
pos = 0
finish = False

def createThread(con):
    thread = threading.Thread(target=con)
    thread.daemon = True
    thread.start()

def receive():
    global start,user,player2,board
    while True:     
        if start and not user:
            try:
                data,addr = clientSocket.recvfrom(1024)
                name = data.decode()
                print(data)
                board = gb.Board(name)
                player2 = name
                sendData = '{}'.format("player1").encode()
                clientSocket.send(sendData)
                user = True
            except:
                pass
            
#Recibir el movimiento del player2
def receiveMove():
    global pos,start
    while True:
        if start and user:
            try:
                data,addr = clientSocket.recvfrom(1024)
                data = data.decode()
                print(data)
                if data == "Jugar de Nuevo":              
                    reset()
                elif data == "Divertidos":               
                    gameOver()                         
                else:
                    pos,board.lastMove = data.split("-")
                    board.playMoveOnBoard(int(pos),board.lastMove)
                    updateBoard()
                    lblTurn["text"] = "Tu"
                    play()
            except:
                pass


#Aceptando la coneccion de player2
def acceptConnection():
    print("Thread created")
    global clientSocket,clientAddress,start
    clientSocket,clientAddress = serverSocket.accept()
    message = "Solicitud de reproducción entrante de "+str(clientAddress)+" cliente?"
    answer = messagebox.askyesno("Atencion",message)
    if answer:
        sendData = '{}'.format("aceptado").encode()
        clientSocket.send(sendData)
        start = True
        reset()
        resetStat()
        print(sendData)
        print("Cliente conectado a: ",clientAddress)
        receive()
    else:
        sendData = '{}'.format("No fue Aceptado").encode()
        clientSocket.send(sendData)
        clientSocket.close()
        print("El socket del cliente se cierra")
    
def clickQuit():
    if start or user:
        serverSocket.close()
    window.destroy()    

createThread(acceptConnection)
createThread(receiveMove)

#Ventana disenio
window=Tk()
window.title("player1")
window.geometry("850x650+100+100")
window.configure(background = 'MediumAquamarine')

tops = Frame(window, bg ='MediumAquamarine', pady =2, width = 1350, height=100, relief = RIDGE)
tops.grid(row=0, column =0)

lblTitle = Label(tops, font=('arial',50,'bold'),text="Juego Tic Tac Toe ", bd=21, bg='MediumAquamarine',fg='Cornsilk',justify = CENTER)
lblTitle.grid(row=0,column = 0)

mainFrame = Frame (window, bg = 'Powder Blue', bd=10,width = 1350, height=600, relief=RIDGE) 
mainFrame.grid(row=1,column=0)

leftFrame = Frame (mainFrame ,bd=10, width =750, height=500, pady=2, padx=10, bg="MediumAquamarine", relief=RIDGE)
leftFrame.pack(side=LEFT)

rightFrame = Frame (mainFrame,bd=10, width =560, height=500, padx=10, pady=2, bg="MediumAquamarine", relief=RIDGE)
rightFrame.pack(side=RIGHT)

rightFrame1=Frame(rightFrame ,bd=10, width=560, height=200, padx=10, pady=2, bg="MediumAquamarine", relief=RIDGE) 
rightFrame1.grid(row=0, column=0)

rightFrame2 = Frame(rightFrame,bd=10, width =560, height=250, padx=10, pady=2, bg="MediumAquamarine", relief=RIDGE)
rightFrame2.grid(row=1,column=0)

rightFrame3=Frame(rightFrame ,bd=10, width=560, height=150, padx=10, pady=2, bg="MediumAquamarine", relief=RIDGE) 
rightFrame3.grid(row=2, column=0)


def clicked1():
    global finish,board
    if start and user and btn1["text"]==" ":   #Para obtener el texto de los botones del cuadro que el jugador elija
        if board.lastMove == player2:
            btn1["text"]="O"
            board.lastMove = "player1"
            sendData = '{}-{}'.format("0",board.lastMove).encode()
            clientSocket.send(sendData)
            board.playMoveOnBoard(0,board.lastMove)
            lblTurn["text"] = "Oponente" #muestra de quien es el turno
            print(sendData)
            play()

def clicked2():
    global finish,board
    if start and user and btn2["text"]==" ":   #Para obtener el texto de los botones del cuadro que el jugador elija
        if board.lastMove == player2:
            btn2["text"]="O"
            board.lastMove = "player1"
            sendData = '{}-{}'.format("1",board.lastMove).encode()
            clientSocket.send(sendData)
            board.playMoveOnBoard(1,board.lastMove)
            lblTurn["text"] = "Oponente" #muestra de quien es el turno
            print(sendData)
            play()

def clicked3():
    global finish,board
    if start and user and btn3["text"]==" ":   #Para obtener el texto de los botones del cuadro que el jugador elija
        if board.lastMove == player2:
            btn3["text"]="O"
            board.lastMove = "player1"
            sendData = '{}-{}'.format("2",board.lastMove).encode()
            clientSocket.send(sendData)
            board.playMoveOnBoard(2,board.lastMove)
            lblTurn["text"] = "Oponente" #muestra de quien es el turno
            print(sendData)
            play()

def clicked4():
    global finish,board
    if start and user and btn4["text"]==" ":   #Para obtener el texto de los botones del cuadro que el jugador elija
        if board.lastMove == player2:
            btn4["text"]="O"
            board.lastMove = "player1"
            sendData = '{}-{}'.format("3",board.lastMove).encode()
            clientSocket.send(sendData)
            board.playMoveOnBoard(3,board.lastMove)
            lblTurn["text"] = "Oponente" #muestra de quien es el turno
            print(sendData)
            play()

def clicked5():
    global finish,board
    if start and user and btn5["text"]==" ":   #Para obtener el texto de los botones del cuadro que el jugador elija
        if board.lastMove == player2:
            btn5["text"]="O"
            board.lastMove = "player1"
            sendData = '{}-{}'.format("4",board.lastMove).encode()
            clientSocket.send(sendData)
            board.playMoveOnBoard(4,board.lastMove)
            lblTurn["text"] = "Oponente" #muestra de quien es el turno
            print(sendData)
            play()

def clicked6():
    global finish,board
    if start and user and btn6["text"]==" ":   #Para obtener el texto de los botones del cuadro que el jugador elija
        if board.lastMove == player2:
            btn6["text"]="O"
            board.lastMove = "player1"
            sendData = '{}-{}'.format("5",board.lastMove).encode()
            clientSocket.send(sendData)
            board.playMoveOnBoard(5,board.lastMove)
            lblTurn["text"] = "Oponente" #muestra de quien es el turno
            print(sendData)
            play()

def clicked7():
    global finish,board
    if start and user and btn7["text"]==" ":   #Para obtener el texto de los botones del cuadro que el jugador elija
        if board.lastMove == player2:
            btn7["text"]="O"
            board.lastMove = "player1"
            sendData = '{}-{}'.format("6",board.lastMove).encode()
            clientSocket.send(sendData)
            board.playMoveOnBoard(6,board.lastMove)
            lblTurn["text"] = "Oponente" #muestra de quien es el turno
            print(sendData)
            play()

def clicked8():
    global finish,board
    if start and user and btn8["text"]==" ":   #Para obtener el texto de los botones del cuadro que el jugador elija
        if board.lastMove == player2:
            btn8["text"]="O"
            board.lastMove = "player1"
            sendData = '{}-{}'.format("7",board.lastMove).encode()
            clientSocket.send(sendData)
            board.playMoveOnBoard(7,board.lastMove)
            lblTurn["text"] = "Oponente" #muestra de quien es el turno
            print(sendData)
            play()

def clicked9():
    global finish,board
    if start and user and btn9["text"]==" ":   #Para obtener el texto de los botones del cuadro que el jugador elija
        if board.lastMove == player2:
            btn9["text"]="O"
            board.lastMove = "player1"
            sendData = '{}-{}'.format("8",board.lastMove).encode()
            clientSocket.send(sendData)
            board.playMoveOnBoard(8,board.lastMove)
            lblTurn["text"] = "Oponente" #muestra de quien es el turno
            print(sendData)
            play()


def play():
    finish,won = board.isGameFinished()
    if finish:
        board.recordGamePlayed()
        board.resetGameBoard()
        board.lastMove = "player1"
        
def gameOver():
    isCon = False
    start = False
    user = False
    close = True
    clientSocket.close()
    board.numGames = board.numGames - 1
    comData = board.computeStats()
    lblGames["text"] = comData["numGames"]
    lblWon["text"] = comData["wins"]["O"]
    lblLost["text"] = comData["loss"]["O"]
    lblTies["text"] = comData["ties"]
    lblTurn["text"] = "Oponente"
    reset()

def reset():
    btn1["text"]=" "
    btn2["text"]=" "
    btn3["text"]=" "
    btn4["text"]=" "
    btn5["text"]=" "
    btn6["text"]=" "
    btn7["text"]=" "
    btn8["text"]=" "
    btn9["text"]=" "


def resetStat():
    lblTurn["text"] = "Oponente"
    lblGames["text"] = " "
    lblWon["text"] = " "
    lblLost["text"] = " "
    lblTies["text"] = " "  

def updateBoard():
    if int(pos) == 0:
        btn1["text"]="X"
    elif int(pos) == 1:
        btn2["text"]="X"
    elif int(pos) == 2:
        btn3["text"]="X"
    elif int(pos) == 3:
        btn4["text"]="X"
    elif int(pos) == 4:
        btn5["text"]="X"
    elif int(pos) == 5:
        btn6["text"]="X"
    elif int(pos) == 6:
        btn7["text"]="X"
    elif int(pos) == 7:
        btn8["text"]="X"
    elif int(pos) == 8:
        btn9["text"]="X"


btn1 = Button(leftFrame, text=" ",bg="white", fg="Black",width=8,height=3,font=('Times', 20),command=clicked1)
btn1.grid(column=1, row=1, sticky = S+N+E+W)
btn2 = Button(leftFrame, text=" ",bg="white", fg="Black",width=8,height=3,font=('Times', 20), command=clicked2)
btn2.grid(column=2, row=1, sticky = S+N+E+W)
btn3 = Button(leftFrame, text=" ",bg="white", fg="Black",width=8,height=3,font=('Times', 20),command=clicked3)
btn3.grid(column=3, row=1, sticky = S+N+E+W)
btn4 = Button(leftFrame, text=" ",bg="white", fg="Black",width=8,height=3,font=('Times', 20),command=clicked4)
btn4.grid(column=1, row=2, sticky = S+N+E+W)
btn5 = Button(leftFrame, text=" ",bg="white", fg="Black",width=8,height=3,font=('Times', 20),command=clicked5)
btn5.grid(column=2, row=2, sticky = S+N+E+W)
btn6 = Button(leftFrame, text=" ",bg="white", fg="Black",width=8,height=3,font=('Times', 20),command=clicked6)
btn6.grid(column=3, row=2, sticky = S+N+E+W)
btn7 = Button(leftFrame, text=" ",bg="white", fg="Black",width=8,height=3,font=('Times', 20),command=clicked7)
btn7.grid(column=1, row=3, sticky = S+N+E+W)
btn8 = Button(leftFrame, text=" ",bg="white", fg="Black",width=8,height=3,font=('Times', 20),command=clicked8)
btn8.grid(column=2, row=3, sticky = S+N+E+W)
btn9 = Button(leftFrame, text=" ",bg="white", fg="Black",width=8,height=3,font=('Times', 20),command=clicked9)
btn9.grid(column=3, row=3, sticky = S+N+E+W)

#Boton cancelar
btnQuit=Button (rightFrame3, text="Salir", font=('arial', 20, 'bold'), height = 1, width =15,command = clickQuit) 
btnQuit.grid(row=2, column=1 ,padx=6, pady=10)

#Resultados

lbl=Label(rightFrame2, font=('arial', 20, 'bold'), text="JUEGOS:",padx=2, pady=2, bg="MediumAquamarine") 
lbl.grid (row=0, column=0, sticky=W)
lblGames=Label(rightFrame2, font=('arial', 20, 'bold'), text=" ",padx=2, pady=2, bg="MediumAquamarine",width=8) 
lblGames.grid (row=0, column=1, sticky=W)
lbl=Label(rightFrame2, font=('arial', 20, 'bold'), text="Ganado:",padx=2, pady=2, bg="MediumAquamarine") 
lbl.grid (row=1, column=0, sticky=W)
lblWon=Label(rightFrame2, font=('arial', 20, 'bold'), text=" ",padx=2, pady=2, bg="MediumAquamarine",width=8) 
lblWon.grid (row=1, column=1, sticky=W)
lbl=Label(rightFrame2, font=('arial', 20, 'bold'), text="Perdido:",padx=2, pady=2, bg="MediumAquamarine") 
lbl.grid (row=2, column=0, sticky=W)
lblLost=Label(rightFrame2, font=('arial', 20, 'bold'), text=" ",padx=2, pady=2, bg="MediumAquamarine",width=8) 
lblLost.grid (row=2, column=1, sticky=W)
lbl=Label(rightFrame2, font=('arial', 20, 'bold'), text="Empate:",padx=2, pady=2, bg="MediumAquamarine") 
lbl.grid (row=3, column=0, sticky=W)
lblTies=Label(rightFrame2, font=('arial', 20, 'bold'), text=" ",padx=2, pady=2, bg="MediumAquamarine",width=8) 
lblTies.grid (row=3, column=1, sticky=W)

#Menu del player 

lbl=Label(rightFrame1, font=('arial', 20, 'bold'), text="Host:",padx=2, pady=2, bg="MediumAquamarine") 
lbl.grid (row=0, column=0, sticky=W)
lblUsername=Label(rightFrame1, font=('arial', 20, 'bold'), text="player1",padx=2, pady=2, bg="MediumAquamarine",width=10) 
lblUsername.grid (row=0, column=1, sticky=W)
lbl=Label(rightFrame1, font=('arial', 20, 'bold'), text="Turno: ",padx=2, pady=2, bg="MediumAquamarine") 
lbl.grid (row=1, column=0, sticky=W)
lblTurn=Label(rightFrame1, font=('arial', 20, 'bold'), text="Oponente",padx=2, pady=2, bg="MediumAquamarine",width=10) 
lblTurn.grid (row=1, column=1, sticky=W)

window.mainloop()